package onlineshopingmall;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author M.Ali
 */
public class Order {
    String userEmail;
    int prodID;
    int Quantity;
    List <OrderList> orderlist = new ArrayList<OrderList>();
    public Order(){
        userEmail="";
        prodID=0;
        Quantity=0;
    }
    public void AddOrder(String userEmail, int prodID, int Quantity)
    {   
        OrderList ordList = new OrderList();
        ordList.userEmail=userEmail;
        ordList.prodID=prodID;
        ordList.Quantity=Quantity;
        orderlist.add(ordList);
    }
    
    public List getOrders(){
        return orderlist;
    }
}
class OrderList extends Order{
}