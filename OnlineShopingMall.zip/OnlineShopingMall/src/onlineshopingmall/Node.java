package onlineshopingmall;		

import java.lang.reflect.Field;

public class Node {
	public Object data;
        // int data;
	public Node next;
	
	public Node(Object data){
            this.data=data;
            this.next=null;	
	}

        public Node(Node another,String s) {  
          this.data = another.data; // you can access
          this.next = another.next;
        }

	public void insert(Object data){
            Node p =new Node(data);
            Node temp=this;
            while(temp.next!=null){
                    temp=temp.next;
            }
            temp.next=p;
	}
        public Node sortList(String FiledName){
            Node temp = new Node(this,"");
            try{
                Field field = temp.data.getClass().getDeclaredField(FiledName);    
                while(temp.next!=null){
                   String data = field.get(temp.data).toString();
                   String data1 = field.get(temp.next.data).toString();
                   if(data.compareTo(data1)>0){
                       Node temp2 = temp.next.next;
                       temp.next.next = temp;
                       temp.next=temp2;
                   }
                   temp=temp.next;
                }
            }
            catch(Exception e)
            {
                System.out.println("There must be somthing wrong");
            }
            return temp;
        }
	public void insertMid(Object data){
		Node p =new Node(data);
		Node temp=this;
		for(int ind=1;ind<this.getSize()/2;ind++){
			temp=temp.next;
		}
		p.next=temp.next;
		temp.next=p;
	}
	public void appendAfter(int loc,Object data){
		Node p =new Node(data);
		Node temp=this;
		int ind=loc;
		if(ind>0 && ind<=this.getSize()){
			for(int i=1;i<ind;i++){
				temp=temp.next;
			}
			p.next=temp.next;
			temp.next=p;
		}
		else{
			System.out.println("Invalid specified location");
		}
	}
	public void appendAfterData(int datasearch,Object data){
		Node p =new Node(data);
		Node temp=this;
		int ind=this.searchItem(datasearch);
		if(ind>0 && ind<=this.getSize()){
			for(int i=1;i<ind;i++){
				temp=temp.next;
			}
			p.next=temp.next;
			temp.next=p;
		}
		else{
			System.out.println("Invalid specified location");
		}
	}
	public void insertFirstLoc(Object data){
	    Node p =new Node(this.data);
		p.next=this.next;
		this.data=data;
		this.next=p;
		System.out.println(p.data);
	}
	public int getSize(){
		Node temp=this;
		int count=1;
		while(temp.next!=null){
			count++;
			temp=temp.next;
		}
	    return count;
	}
	public void Display(){
            Node temp=this;
            int index=0;
            while(temp!=null){
                    System.out.print((++index)+". "+temp.data+"\n");
                    temp=temp.next;
            }
	}
	public int searchItem(Object data){
            // Search  by Data
            Node temp=this;
            int ind=1;
            while(temp.next!=null && temp.data!=data){
                    ind++;
                    temp=temp.next;
            }
            if(temp.data!=data){
                    ind=-1;
            }
            return ind;
	}
	public void updateByLoc(int loc,Object data){
            Node temp=this;
            int ind=loc;
            if(ind>0 && ind<=this.getSize()){
                    for(int i=1;i<ind;i++){
                            temp=temp.next;
                    }
                    temp.data=data;
            }
            else{
                    System.out.println("Invalid specified location");
            }
	}
	public void updateBysearchedData(int dataSearch,Object data){
            Node temp=this;
            int ind=this.searchItem(dataSearch);
            if(ind>0 && ind<=this.getSize()){
                    for(int i=1;i<ind;i++){
                            temp=temp.next;
                    }
                    temp.data=data;
            }
            else{
                    System.out.println("Invalid specified location");
            }
		
	}
	public void deleteByData(Object data){
		Node temp=this;
		int ind=this.searchItem(data);
		if(ind>0){
			for(int i=1;i<ind-1;i++)
			{
				temp=temp.next;		
			}
			if(ind==1){
				temp.data=0;
				if(this.getSize()>1){
					temp.data=temp.next.data;
					temp.next=temp.next.next;
				}
			}	
		    else{
				temp.next=temp.next.next;
			}
		}
		else{
			System.out.println("Specified data is not in the LinkedList");
		}
	}
	public void deleteByLoc(int loc){
		
		Node temp=this;
		int ind=loc;
		if(ind>0 && ind<=this.getSize()){
			for(int i=1;i<ind-1;i++)
			{
				temp=temp.next;		
			}
			if(ind==1){
				temp.data=0;
				if(this.getSize()>1){
					temp.data=temp.next.data;
					temp.next=temp.next.next;
				}
			}	
		    else{
				temp.next=temp.next.next;
			}
		}
		else{
			System.out.println("Invalid specified location");
		}
		
	}
	 
}