package onlineshopingmall;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.HBox;

/**
 *
 * @author M.Ali
 */
public class OnlineShopingMall extends Application {
    //Stage stage = new Stage();
    Person person = new Person();
    Product prod= new Product();
    Order order = new Order();
    VBox root  = new VBox();
    Scene scene = new Scene(root);
    String currentUser="";
    @Override
    public void start(Stage stage) throws Exception {
       // Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
       prod.addProduct("prd2", "tp2", 2, 22, "cat2", "col2", "sha2", 223);
       prod.addProduct("prd1", "tp1", 1, 12, "cat1", "col1", "sha1", 123);
       prod.addProduct("prd2", "tp2", 2, 22, "cat2", "col2", "sha2", 223);
       prod.addProduct("prd3", "tp3", 3, 33, "cat3", "col3", "sha3", 323);
       
       root.setAlignment(Pos.CENTER);
       root.setPadding(new Insets(11.5,12.5,45,14.5));
       root.setSpacing(30);   
        
       Label lblWelcm= new Label("Welcoom To Inventory System");
       lblWelcm.setAlignment(Pos.CENTER);
       lblWelcm.setFont(Font.font(STYLESHEET_CASPIAN, 20));
       Button adLogn = new Button("Admin Login");
       Button cstLogn = new Button("Customer Login");
       Button cstSgnup = new Button("Sign up");
       
       root.getChildren().add(lblWelcm);
       root.setMargin(lblWelcm, new Insets(20, 0, 20, 0));  
       HBox hbox = new HBox();
       root.setSpacing(3);
       
       hbox.getChildren().add(adLogn);
       hbox.setMargin(adLogn, new Insets(0, 5, 0, 0));
       hbox.getChildren().add(cstLogn);
       hbox.setMargin(cstLogn, new Insets(0, 5, 0, 0));
       hbox.getChildren().add(cstSgnup);
       
       root.getChildren().add(hbox); 
       cstSgnup.addEventHandler(MouseEvent.MOUSE_CLICKED,new EventHandler<MouseEvent>() {
            public void handle(MouseEvent event) {
                GridPane grid;
                grid=SignupPage(stage);   
                Scene scene2 = new Scene(grid);
                stage.setTitle("Signup Page");
                stage.setScene(scene2);
                stage.close();
                stage.show();
            }
       });
       
       cstLogn.addEventHandler(MouseEvent.MOUSE_CLICKED,new EventHandler<MouseEvent>() {
            public void handle(MouseEvent event) {
                GridPane grid;
                grid=LoginPage(stage);   
                Scene scene2 = new Scene(grid);
                stage.setTitle("Login Page");
                stage.setScene(scene2);
                stage.close();
                stage.show();
            }
       });
       adLogn.addEventHandler(MouseEvent.MOUSE_CLICKED,new EventHandler<MouseEvent>() {
            public void handle(MouseEvent event) {
                GridPane grid;
                grid=AdminLoginPage(stage);   
                Scene scene2 = new Scene(grid);
                stage.setTitle("Admin Login Page");
                stage.setScene(scene2);
                stage.close();
                stage.show();
            }
       });
       
       stage.setTitle("Welcome");
       stage.setScene(scene);
       stage.show();
       
    }
    
    public GridPane SignupPage(Stage stage){
        
        GridPane pane  = new GridPane();
        pane.setAlignment(Pos.CENTER);
        pane.setPadding(new Insets(11.5,12.5,13.5,14.5));
        pane.setHgap(5);
        pane.setVgap(5);
        //root.setSpacing(10);
        Label lblSignup= new Label("Sign up");
        lblSignup.setAlignment(Pos.CENTER);
        lblSignup.setFont(Font.font(STYLESHEET_CASPIAN, 20));
        Label lblname= new Label("Full Name ");
        TextField txtname = new TextField();
        Label lblemail= new Label("Email");
        TextField txtemail = new TextField();
        Label lblpass= new Label("Password");
        PasswordField txtpass = new PasswordField();    
        Label lblcontact= new Label("Contact");
        TextField txtcontact = new TextField();
        Button backbtn = new Button("Back");
        backbtn.setAlignment(Pos.CENTER_RIGHT);
        Button Submit = new Button("Signup");
        Submit.setAlignment(Pos.CENTER_RIGHT);
        
	pane.add(lblSignup,1,0);
        pane.add(lblname,0,3);
        pane.add(txtname,1,3);
        pane.add(lblemail,0,4);
        pane.add(txtemail,1,4);
        pane.add(lblpass,0,5);
        pane.add(txtpass,1,5);
        pane.add(lblcontact,0,6);
        pane.add(txtcontact,1,6);
        pane.add(backbtn,0,7);
        pane.add(Submit,2,7);
        
        Submit.addEventHandler(MouseEvent.MOUSE_CLICKED,new EventHandler<MouseEvent>() {
            public void handle(MouseEvent event) {
                boolean checkTextField=true;
                if(txtname.getText().length()==0){
                    checkTextField=false;
                }
                if(txtemail.getText().length()==0){
                    checkTextField=false;
                }
                if(txtpass.getText().length()==0){
                    checkTextField=false;
                }
                if(txtcontact.getText().length()==0){
                    checkTextField=false;
                }
                if(checkTextField){
                   boolean isSignup = person.getSignup(txtname.getText(), txtcontact.getText(), 2, txtemail.getText(), txtpass.getText());
                   //isSignup = person.getSignup(txtname.getText(), txtcontact.getText(), 2, txtemail.getText(), txtpass.getText());
                   if(isSignup)
                   {
                       List<Person> personList= person.getCustomers();
                       //personList= personList.clone();
                       txtname.setText("");
                       txtemail.setText("");
                       txtpass.setText("");
                       txtcontact.setText("");
                       Alert a = new Alert(AlertType.INFORMATION,"Accont successfully created");
                       a.show(); 
                        //for(int i=0;i<personList.size();i++){
                        //   System.out.println(personList.get(i).name);                                                             
                       //}    
                   }
                   else{
                       Alert a = new Alert(AlertType.ERROR,"Email already exist");
                       a.show(); 
                   }
                }
                else{
                    Alert a = new Alert(AlertType.ERROR,"You must fill all the fields");
                    a.show();
                }
            }
        });
        backbtn.addEventHandler(MouseEvent.MOUSE_CLICKED,new EventHandler<MouseEvent>() {
            public void handle(MouseEvent event) {
                stage.close();
                stage.setTitle("Welcome");
                stage.setScene(scene);
                stage.show();
            }
        });
        return pane;
    }
    public GridPane LoginPage(Stage stage){
        GridPane pane = new GridPane();
        pane.setAlignment(Pos.CENTER);
        pane.setPadding(new Insets(11.5,12.5,13.5,14.5));
        pane.setHgap(5);
        pane.setVgap(5);
        
        Label lblLogin= new Label("Login");
        lblLogin.setAlignment(Pos.CENTER);
        lblLogin.setFont(Font.font(STYLESHEET_CASPIAN, 20));
        Label lblemail= new Label("Email");
        TextField txtemail = new TextField();
        Label lblpass= new Label("Password");
        PasswordField txtpass = new PasswordField(); 
        Button backbtn = new Button("Back");
        backbtn.setAlignment(Pos.CENTER_RIGHT);
        Button Submit = new Button("Login");
        Submit.setAlignment(Pos.CENTER_RIGHT);
        
        pane.add(lblLogin,1,0);
        pane.add(lblemail,0,3);
        pane.add(txtemail,1,3);
        pane.add(lblpass,0,4);
        pane.add(txtpass,1,4);
        pane.add(backbtn,1,5);
        pane.add(Submit,2,5);
        
        Submit.addEventHandler(MouseEvent.MOUSE_CLICKED,new EventHandler<MouseEvent>() {
            public void handle(MouseEvent event) {
                boolean checkTextField=true;
                if(txtemail.getText().length()==0){
                    checkTextField=false;
                }
                if(txtpass.getText().length()==0){
                    checkTextField=false;
                }
                if(checkTextField){
                  String email = person.getLogin(txtemail.getText(), txtpass.getText());
                  if(email!="")
                  {
                    currentUser = email;
                    viewProductCustomer(pane,stage);  
                    Alert a = new Alert(AlertType.INFORMATION,"You have successfully loged in");
                    a.show(); 
                  }
                }
            }
        });
        backbtn.addEventHandler(MouseEvent.MOUSE_CLICKED,new EventHandler<MouseEvent>() {
            public void handle(MouseEvent event) {
                stage.close();
                stage.setTitle("Welcome");
                stage.setScene(scene);
                stage.show();
            }
        });
        return (pane);
    }
    
     public GridPane AdminLoginPage(Stage stage){
        GridPane pane = new GridPane();
        pane.setAlignment(Pos.CENTER);
        pane.setPadding(new Insets(11.5,12.5,13.5,14.5));
        pane.setHgap(5);
        pane.setVgap(5);
        
        Label lblLogin= new Label("Login");
        lblLogin.setAlignment(Pos.CENTER);
        lblLogin.setFont(Font.font(STYLESHEET_CASPIAN, 20));
        Label lblemail= new Label("Email");
        TextField txtemail = new TextField();
        Label lblpass= new Label("Password");
        PasswordField txtpass = new PasswordField(); 
        Button backbtn = new Button("Back");
        backbtn.setAlignment(Pos.CENTER_RIGHT);
        Button Submit = new Button("Login");
        Submit.setAlignment(Pos.CENTER_RIGHT);
        
        pane.add(lblLogin,1,0);
        pane.add(lblemail,0,3);
        pane.add(txtemail,1,3);
        pane.add(lblpass,0,4);
        pane.add(txtpass,1,4);
        pane.add(backbtn,0,5);
        pane.add(Submit,2,5);
        
        Submit.addEventHandler(MouseEvent.MOUSE_CLICKED,new EventHandler<MouseEvent>() {
            public void handle(MouseEvent event) {
                boolean checkTextField=true;
                if(txtemail.getText().length()==0){
                    checkTextField=false;
                }
                if(txtpass.getText().length()==0){
                    checkTextField=false;
                }
                if(checkTextField){
                  boolean isLogedin = person.AdminLogin(txtemail.getText(), txtpass.getText());
                  if(isLogedin)
                  {
                    //Alert a = new Alert(AlertType.INFORMATION,"You have successfully loged in");
                    //a.show(); 
                    AdminProductOperation(pane,stage);       
                  }
                  else{
                      Alert a = new Alert(AlertType.ERROR,"Your Credentials does not match");
                    a.show();
                  }
                }
            }
        });
        backbtn.addEventHandler(MouseEvent.MOUSE_CLICKED,new EventHandler<MouseEvent>() {
            public void handle(MouseEvent event) {
                stage.close();
                stage.setTitle("Welcome");
                stage.setScene(scene);
                stage.show();
            }
        });
        return (pane);
    }
    
    public void AdminProductOperation(GridPane pane, Stage stage){
       VBox vbox1 = new VBox();
       
       vbox1.setAlignment(Pos.CENTER);
       vbox1.setPadding(new Insets(11.5,12.5,45,14.5));
       vbox1.setSpacing(30);   
        
       Label lblWelcm= new Label("Manage Products");
       lblWelcm.setAlignment(Pos.CENTER);
       lblWelcm.setFont(Font.font(STYLESHEET_CASPIAN, 20));
       Button logoutbtn = new Button("Logout");
       HBox hBox=new HBox();
       hBox.getChildren().add(logoutbtn);
       hBox.setAlignment(Pos.BASELINE_RIGHT);
       Button addprod = new Button("Add Prduct");
       Button showProd = new Button("Show Product");
       Button cstList = new Button("Customer List");
       Button showOrder = new Button("Order List");
       
       vbox1.getChildren().add(hBox);
       vbox1.setMargin(logoutbtn, new Insets(10, 100, 0, 0));
       vbox1.getChildren().add(lblWelcm);
       vbox1.setMargin(lblWelcm, new Insets(20, 0, 20, 0));  
       HBox hbox = new HBox();
       vbox1.setSpacing(3);
       
       hbox.getChildren().add(addprod);
       hbox.setMargin(addprod, new Insets(0, 5, 0, 0));
       hbox.getChildren().add(showProd);
       hbox.setMargin(showProd, new Insets(0, 5, 0, 0));
       hbox.getChildren().add(cstList);
       hbox.setMargin(cstList, new Insets(0, 5, 0, 0));
       hbox.getChildren().add(showOrder);
       vbox1.getChildren().add(hbox);
       
       logoutbtn.addEventHandler(MouseEvent.MOUSE_CLICKED,new EventHandler<MouseEvent>() {
            public void handle(MouseEvent event) {
                stage.close();
                stage.setTitle("Welcome");
                stage.setScene(scene);
                stage.show();
            }
        });
       
       addprod.addEventHandler(MouseEvent.MOUSE_CLICKED,new EventHandler<MouseEvent>() {
            public void handle(MouseEvent event) {
                addProduct(vbox1,stage);
            }
        });
       showProd.addEventHandler(MouseEvent.MOUSE_CLICKED,new EventHandler<MouseEvent>() {
            public void handle(MouseEvent event) {
                showProduct(vbox1,stage);
            }
        });
       cstList.addEventHandler(MouseEvent.MOUSE_CLICKED,new EventHandler<MouseEvent>() {
            public void handle(MouseEvent event) {
                showCustomer(vbox1,stage);
            }
        });
       
       showOrder.addEventHandler(MouseEvent.MOUSE_CLICKED,new EventHandler<MouseEvent>() {
            public void handle(MouseEvent event) {
                showOrder(vbox1,stage);
            }
        });
       
       stage.close();
       Scene scene2 = new Scene(vbox1);
       stage.setTitle("Manage Products");
       stage.setScene(scene2);
       stage.show();
    } 
    
    public void addProduct(VBox vbox1,Stage stage){
        GridPane pane  = new GridPane();
        pane.setAlignment(Pos.CENTER);
        pane.setPadding(new Insets(11.5,12.5,13.5,14.5));
        pane.setHgap(5);
        pane.setVgap(5);
        //root.setSpacing(10);
        Label lblTitle= new Label("Add Product");
        lblTitle.setAlignment(Pos.CENTER);
        lblTitle.setFont(Font.font(STYLESHEET_CASPIAN, 20));
       
        Label lblname= new Label("Product Name ");
        TextField prodname = new TextField();
        Label lblCatg= new Label("Product Category");
        TextField txtCatg = new TextField();
        Label lblqunty= new Label("Quantity");
        TextField txtqunty = new TextField();
        txtqunty.setText("0");
        Label lblprice= new Label("Price");
        TextField txtprice = new TextField();
        txtprice.setText("0.0");
        Label lblCmpny= new Label("Company");
        TextField txtCmpny = new TextField();
        Label lblDesc= new Label("Description");
        TextField txtDesc = new TextField();
        Label lblColor= new Label("Color(optional)");
        TextField txtColor = new TextField();
        Label lblSize= new Label("Size(optional)");
        TextField txtSize = new TextField();
        txtSize.setText("0.0");
        Button backbtn = new Button("Back");
        backbtn.setAlignment(Pos.CENTER_RIGHT);
        Button Submit = new Button("Add");
        Submit.setAlignment(Pos.CENTER_RIGHT);
        
	pane.add(lblTitle,1,0);
        pane.add(lblname,0,3);
        pane.add(prodname,1,3);
        pane.add(lblCatg,0,4);
        pane.add(txtCatg,1,4);
        pane.add(lblqunty,0,5);
        pane.add(txtqunty,1,5);
        pane.add(lblprice,0,6);
        pane.add(txtprice,1,6);
        pane.add(lblCmpny,0,7);
        pane.add(txtCmpny,1,7);
        pane.add(lblDesc,0,8);
        pane.add(txtDesc,1,8);
        pane.add(lblColor,0,9);
        pane.add(txtColor,1,9);
        pane.add(lblSize,0,10);
        pane.add(txtSize,1,10);
        pane.add(backbtn,0,11);
        pane.add(Submit,2,11);
       // pane.add(vbox1,1,11);
        
        backbtn.addEventHandler(MouseEvent.MOUSE_CLICKED,new EventHandler<MouseEvent>() {
            public void handle(MouseEvent event) {
               AdminProductOperation(AdminLoginPage(stage),stage);
            }
        });
        Submit.addEventHandler(MouseEvent.MOUSE_CLICKED,new EventHandler<MouseEvent>() {
            public void handle(MouseEvent event) {
                boolean isfilled=false;
                int quantity = Integer.parseInt(txtqunty.getText());
                double price = Double.parseDouble(txtprice.getText());
                double size;
                try{
                    size = Double.parseDouble(txtSize.getText());
                }
                catch(NumberFormatException e){
                    size =0.0;
                }
                isfilled = prod.addProduct(prodname.getText(), txtCatg.getText(), quantity, price, txtCmpny.getText(),txtDesc.getText(),txtColor.getText(),size);
                if(isfilled)
                {
                   // List<Product> prodList= prod.getProduct();
                    
                    prodname.setText("");
                    txtCatg.setText("");
                    txtqunty.setText("0");
                    txtprice.setText("0.0");
                    txtCmpny.setText("");
                    txtDesc.setText("");
                    txtColor.setText("");
                    txtSize.setText("0.0");
                    Alert a = new Alert(AlertType.INFORMATION,"Product has been Added");
                    a.show(); 
                }
                else{
                    Alert a = new Alert(AlertType.ERROR,"You must fill all required fields");
                    a.show(); 
                }
            }
        });
        stage.close();
        Scene scene2 = new Scene(pane);
        stage.setTitle("Add Product");
        stage.setScene(scene2);
        stage.show();
    }
    public void showProduct(VBox vbox1,Stage stage){
       GridPane pane  = new GridPane();
       pane.setAlignment(Pos.CENTER);
       pane.setPadding(new Insets(11.5,12.5,13.5,14.5));
       pane.setHgap(5);
       pane.setVgap(5);
        //root.setSpacing(10);
       Label lblTitle= new Label("Product List");
       lblTitle.setAlignment(Pos.CENTER);
       lblTitle.setFont(Font.font(STYLESHEET_CASPIAN, 20));
       
       pane.add(lblTitle,0,0);
       Node prodList= prod.prodList;
       int row=4;
       if(prodList==null){
          pane.add(new Label("There is no product yet!"),1,2); 
       }
       else{
            Label prodName= new Label("Product Name");
            prodName.setFont(Font.font(STYLESHEET_CASPIAN, 14));
            Label prodCatg= new Label("Category");
            prodCatg.setFont(Font.font(STYLESHEET_CASPIAN, 14));
            Label prodQunty= new Label("Quantity");
            prodQunty.setFont(Font.font(STYLESHEET_CASPIAN, 14));
            Label prodPrice= new Label("Price");
            prodPrice.setFont(Font.font(STYLESHEET_CASPIAN, 14));
            Label prodCompany= new Label("Company");
            prodCompany.setFont(Font.font(STYLESHEET_CASPIAN, 14));
            Label prodDesc= new Label("Description");
            prodDesc.setFont(Font.font(STYLESHEET_CASPIAN, 14));
            Label prodColor= new Label("Color");
            prodColor.setFont(Font.font(STYLESHEET_CASPIAN, 14));
            Label prodSize= new Label("Size");
            prodSize.setFont(Font.font(STYLESHEET_CASPIAN, 14));

            pane.add(prodName,0,3);
            pane.add(prodCatg,1,3);
            pane.add(prodQunty,2,3);
            pane.add(prodPrice,3,3);
            pane.add(prodCompany,4,3);
            pane.add(prodDesc,5,3);
            pane.add(prodColor,6,3);
            pane.add(prodSize,7,3);
            
            Field[] field = prod.prodList.data.getClass().getDeclaredFields();
            try{
                while(prodList!=null){ 
                  String quantity = ""+field[3].get(prodList.data).toString();
                  String price = ""+field[4].get(prodList.data).toString();
                  String size = ""+field[8].get(prodList.data).toString();
                  pane.add(new Label(field[1].get(prodList.data).toString()),0,row);
                  pane.add(new Label(field[2].get(prodList.data).toString()),1,row);
                  pane.add(new Label(quantity),2,row);
                  pane.add(new Label(field[5].get(prodList.data).toString()),3,row);
                  pane.add(new Label(price),4,row);
                  pane.add(new Label(field[6].get(prodList.data).toString()),5,row);
                  pane.add(new Label(field[7].get(prodList.data).toString()),6,row);
                  pane.add(new Label(size),7,row);
                  row++;
                  prodList=prodList.next;
                }
            }
            catch(Exception e){
                 Alert a = new Alert(AlertType.ERROR,"Something went wrong");
            }
       }
       Button backbtn=new Button("Back");
       pane.add(backbtn,0,row);
       backbtn.addEventHandler(MouseEvent.MOUSE_CLICKED,new EventHandler<MouseEvent>() {
            public void handle(MouseEvent event) {
               AdminProductOperation(AdminLoginPage(stage),stage);
            }
        });
       stage.close();
       Scene scene2 = new Scene(pane);
       stage.setTitle("Product List");
       stage.setScene(scene2);
       stage.show();
    }
    public void showCustomer(VBox vbox1,Stage stage){
       GridPane pane  = new GridPane();
       pane.setAlignment(Pos.CENTER);
       pane.setPadding(new Insets(11.5,12.5,13.5,14.5));
       pane.setHgap(5);
       pane.setVgap(5);
        //root.setSpacing(10);
       Label lblTitle= new Label("Customer List");
       lblTitle.setAlignment(Pos.CENTER);
       lblTitle.setFont(Font.font(STYLESHEET_CASPIAN, 20));
       
       pane.add(lblTitle,0,0);
       List<Person> personList= person.getCustomers();
       int row=4;
       if(personList.size()==0){
          pane.add(new Label("There is no customer yet!"),1,2); 
       }
       else{
           
            Label custName= new Label("Customer Name");
            custName.setFont(Font.font(STYLESHEET_CASPIAN, 14));
            Label custEmail= new Label("Email");
            custEmail.setFont(Font.font(STYLESHEET_CASPIAN, 14));
            Label custPass= new Label("Password");
            custPass.setFont(Font.font(STYLESHEET_CASPIAN, 14));
            Label custCont= new Label("Contact");
            custCont.setFont(Font.font(STYLESHEET_CASPIAN, 14));
            
            pane.add(custName,0,3);
            pane.add(custEmail,1,3);
            pane.add(custPass,2,3);
            pane.add(custCont,3,3);
            for(int i=0;i<personList.size();i++){
              
              pane.add(new Label(personList.get(i).name),0,row);
              pane.add(new Label(personList.get(i).email),1,row);
              pane.add(new Label(personList.get(i).password),2,row);
              pane.add(new Label(personList.get(i).contact),3,row);
              row++;
            }
       }
       Button backbtn=new Button("Back");
       pane.add(backbtn,0,row);
       backbtn.addEventHandler(MouseEvent.MOUSE_CLICKED,new EventHandler<MouseEvent>() {
            public void handle(MouseEvent event) {
               AdminProductOperation(AdminLoginPage(stage),stage);
            }
        });
       stage.close();
       Scene scene2 = new Scene(pane);
       stage.setTitle("Customer List");
       stage.setScene(scene2);
       stage.show();
    }
    
     public void showOrder(VBox vbox, Stage stage){
       GridPane pane  = new GridPane();
       pane.setAlignment(Pos.CENTER);
       pane.setPadding(new Insets(11.5,12.5,13.5,14.5));
       pane.setHgap(5);
       pane.setVgap(5);
        //root.setSpacing(10);
       Label lblTitle= new Label("Order List");
       lblTitle.setAlignment(Pos.CENTER);
       lblTitle.setFont(Font.font(STYLESHEET_CASPIAN, 20));
       
       pane.add(lblTitle,0,0);
       List<Order> orderList= order.getOrders();
       int row=4;
       if(orderList.size()==0){
          pane.add(new Label("There is no order yet!"),1,2); 
       }
       else{ 
            Label prodName= new Label("Product Name");
            prodName.setFont(Font.font(STYLESHEET_CASPIAN, 14));
            Label lblCust= new Label("Cutomer Email");
            lblCust.setFont(Font.font(STYLESHEET_CASPIAN, 14));
            Label prodCatg= new Label("Category");
            prodCatg.setFont(Font.font(STYLESHEET_CASPIAN, 14));
            Label prodQunty= new Label("Quantity");
            prodQunty.setFont(Font.font(STYLESHEET_CASPIAN, 14));
            Label prodPrice= new Label("Price");
            prodPrice.setFont(Font.font(STYLESHEET_CASPIAN, 14));
            Label prodCompany= new Label("Company");
            prodCompany.setFont(Font.font(STYLESHEET_CASPIAN, 14));
            Label prodDesc= new Label("Description");
            prodDesc.setFont(Font.font(STYLESHEET_CASPIAN, 14));
            Label prodColor= new Label("Color");
            prodColor.setFont(Font.font(STYLESHEET_CASPIAN, 14));
            Label prodSize= new Label("Size");
            prodSize.setFont(Font.font(STYLESHEET_CASPIAN, 14));

            pane.add(prodName,0,3);
            pane.add(lblCust,1,3);
            pane.add(prodCatg,2,3);
            pane.add(prodQunty,3,3);
            pane.add(prodPrice,4,3);
            pane.add(prodCompany,5,3);
            pane.add(prodDesc,6,3);
            pane.add(prodColor,7,3);
            pane.add(prodSize,8,3);
            Field[] field = prod.prodList.data.getClass().getDeclaredFields();
            for(int i=0;i<orderList.size();i++){
                Node prodList= prod.prodList;
                             // field[1].get(prodList.data).toString() 
               //int j=0;
               boolean isProductFound=false;
               try{
                   while(prodList!=null){
                    //for(;j<prodList.size();j++){
                    int prodID =Integer.parseInt(field[0].get(prodList.data).toString());
                    if(orderList.get(i).prodID==prodID){
                        isProductFound=true;
                        break;
                    }
                    prodList=prodList.next;
                  }
                    if(isProductFound)
                    { 
                       String quantity = ""+field[3].get(prodList.data).toString();
                       String price = ""+field[4].get(prodList.data).toString();
                       String size = ""+field[8].get(prodList.data).toString();

                       pane.add(new Label(field[1].get(prodList.data).toString()),0,row);
                       pane.add(new Label(orderList.get(i).userEmail),1,row);
                       pane.add(new Label(field[2].get(prodList.data).toString()),2,row);
                       pane.add(new Label(quantity),3,row);
                       pane.add(new Label(field[5].get(prodList.data).toString()),4,row);
                       pane.add(new Label(price),5,row);
                       pane.add(new Label(field[6].get(prodList.data).toString()),6,row);
                       pane.add(new Label(field[7].get(prodList.data).toString()),7,row);
                       pane.add(new Label(size),8,row);
                       row++;
                    }
                }
                catch(Exception e){
                   Alert a = new Alert(AlertType.ERROR,"Something went wrong");         
                }    
            }
       }
       Button backbtn=new Button("Back");
       pane.add(backbtn,0,row);
       backbtn.addEventHandler(MouseEvent.MOUSE_CLICKED,new EventHandler<MouseEvent>() {
            public void handle(MouseEvent event) {
               AdminProductOperation(AdminLoginPage(stage),stage);
            }
        });
       stage.close();
       Scene scene2 = new Scene(pane);
       stage.setTitle("Product List");
       stage.setScene(scene2);
       stage.show();
    }        
            
    
    public void viewProductCustomer(GridPane pane, Stage stage){
        System.out.println("Check view customer");
       VBox vbox  = new VBox();
       Node prdList = prod.prodList.sortList("category");  //sortProductbyCat();
       vbox.setAlignment(Pos.CENTER);
       vbox.setPadding(new Insets(11.5,12.5,13.5,14.5));
       Button orderbtn = new Button("Order List");
       Button logoutbtn = new Button("Logout");
       
       HBox hBoxb=new HBox();
       hBoxb.getChildren().add(orderbtn);
       hBoxb.getChildren().add(logoutbtn);
       hBoxb.setAlignment(Pos.BASELINE_RIGHT);
       hBoxb.setMargin(orderbtn, new Insets(0, 5, 0, 0));
       
       logoutbtn.addEventHandler(MouseEvent.MOUSE_CLICKED,new EventHandler<MouseEvent>() {
            public void handle(MouseEvent event) {
                stage.close();
                stage.setTitle("Welcome");
                stage.setScene(scene);
                stage.show();
            }
        });
        orderbtn.addEventHandler(MouseEvent.MOUSE_CLICKED,new EventHandler<MouseEvent>() {
            public void handle(MouseEvent event) {
                showOrderList(pane,stage);
            }
        });
       vbox.getChildren().add(hBoxb);
// vbox.setHgap(5);
      // vbox.setVgap(5);
        //root.setSpacing(10);
       Label lblTitle= new Label("Product List");
       lblTitle.setAlignment(Pos.CENTER);
       lblTitle.setFont(Font.font(STYLESHEET_CASPIAN, 22));
       vbox.getChildren().add(lblTitle);
       HBox hbox=new HBox();
       String txtCatg="";
       String cssLayout = "-fx-border-color: black;\n" +
                   "-fx-border-insets: 5;\n" +
                   "-fx-border-width: 2;\n" +
                   "-fx-border-style: solid;\n"+
                   "-fx-padding: 10;\n";
            //   prlist.get(0).category;
             //  
        int counter=0;
        try{
            while(prdList!=null){//for(int i=0;i<prlist.size();i++){
               //System.out.println("checking"+prlist.get(i).category);
               if(!txtCatg.equals(prdList.data.getClass().getDeclaredField("category").get(prdList.data).toString()))
               {
                        vbox.getChildren().add(hbox);
                        hbox=new HBox();
                        hbox.setSpacing(10);
                        Label lblCatg = new Label(prdList.data.getClass().getDeclaredField("category").get(prdList.data).toString());
                        lblCatg.setFont(Font.font(STYLESHEET_CASPIAN, 18));
                        HBox hBox1=new HBox();
                        hBox1.getChildren().add(lblCatg);
                        hBox1.setAlignment(Pos.BASELINE_LEFT);
                        vbox.getChildren().add(hBox1);
                        counter=0;
                        txtCatg=prdList.data.getClass().getDeclaredField("category").get(prdList.data).toString();
               }
               if(counter==3){
                   counter=0;
                   vbox.getChildren().add(hbox);
                   hbox=new HBox();
                   hbox.setSpacing(10);
               }
               VBox vbx = new VBox();
               Label lblname=new Label("Product name:"+prdList.data.getClass().getDeclaredField("prodName").get(prdList.data).toString());
               lblname.setFont(Font.font(STYLESHEET_CASPIAN, 16));
               Label lblprice=new Label("Price:"+prdList.data.getClass().getDeclaredField("price").get(prdList.data).toString());
               Label lblprodid=new Label("Product ID:"+prdList.data.getClass().getDeclaredField("prodid").get(prdList.data).toString());
               vbx.getChildren().addAll(lblname,lblprice,lblprodid);
               vbx.setStyle(cssLayout);
               hbox.getChildren().add(vbx);
               counter++;
               prdList=prdList.next;
            }
        }
        catch(Exception e){
           Alert a = new Alert(AlertType.ERROR,"Something went wrong");
        }
        if(counter<3)
        vbox.getChildren().add(hbox);
       Label lblprid= new Label("Product id");
       TextField txtprid= new TextField();
       Label lblQunty= new Label("Quantity");
       TextField txtQunty= new TextField();
       Button btnOrder = new Button("Place Order");
       vbox.getChildren().addAll(lblprid,txtprid,lblQunty,txtQunty,btnOrder);
       
       btnOrder.addEventHandler(MouseEvent.MOUSE_CLICKED,new EventHandler<MouseEvent>() {
            public void handle(MouseEvent event) {
             // System.out.println("ShowProductCustomer");
                if(txtprid.getText().length()!=0 && txtQunty.getText().length()!=0 ){
                    order.AddOrder(currentUser,Integer.parseInt(txtprid.getText()), Integer.parseInt(txtQunty.getText()));
                    Alert a = new Alert(AlertType.INFORMATION,"Order has been placed");
                        a.show();
                }
            }
        });
       
       stage.close();
       Scene scene2 = new Scene(vbox);
       stage.setTitle("Product List");
       stage.setScene(scene2);
       stage.show();
    }
    /*
    public Node sortProductbyCat(){
        
        
        List<ProductEntries> prdList = prod.getProduct();
        Collections.sort(prdList, new Comparator<ProductEntries> () {
            @Override
            public int compare(ProductEntries o1, ProductEntries o2) {
                return o1.category.compareTo( o2.category);
            }
        }); 
        return(prdList);
    }
     */
    
     public void showOrderList(GridPane GridPane1, Stage stage){
         GridPane pane  = new GridPane();
       pane.setAlignment(Pos.CENTER);
       pane.setPadding(new Insets(11.5,12.5,13.5,14.5));
       pane.setHgap(5);
       pane.setVgap(5);
        //root.setSpacing(10);
       Label lblTitle= new Label("Order List");
       lblTitle.setAlignment(Pos.CENTER);
       lblTitle.setFont(Font.font(STYLESHEET_CASPIAN, 20));
       
       pane.add(lblTitle,0,0);
       List<Order> orderList= order.getOrders();
       int row=4;
       if(orderList.size()==0){
          pane.add(new Label("There is no order yet!"),1,2); 
       }
       else{ 
            Label prodName= new Label("Product Name");
            prodName.setFont(Font.font(STYLESHEET_CASPIAN, 14));
            Label prodCatg= new Label("Category");
            prodCatg.setFont(Font.font(STYLESHEET_CASPIAN, 14));
            Label prodQunty= new Label("Quantity");
            prodQunty.setFont(Font.font(STYLESHEET_CASPIAN, 14));
            Label prodPrice= new Label("Price");
            prodPrice.setFont(Font.font(STYLESHEET_CASPIAN, 14));
            Label prodCompany= new Label("Company");
            prodCompany.setFont(Font.font(STYLESHEET_CASPIAN, 14));
            Label prodDesc= new Label("Description");
            prodDesc.setFont(Font.font(STYLESHEET_CASPIAN, 14));
            Label prodColor= new Label("Color");
            prodColor.setFont(Font.font(STYLESHEET_CASPIAN, 14));
            Label prodSize= new Label("Size");
            prodSize.setFont(Font.font(STYLESHEET_CASPIAN, 14));

            pane.add(prodName,0,3);
            pane.add(prodCatg,1,3);
            pane.add(prodQunty,2,3);
            pane.add(prodPrice,3,3);
            pane.add(prodCompany,4,3);
            pane.add(prodDesc,5,3);
            pane.add(prodColor,6,3);
            pane.add(prodSize,7,3);
            Field[] field = prod.prodList.data.getClass().getDeclaredFields();
            for(int i=0;i<orderList.size();i++){
                Node prodList= prod.prodList;
                             // field[1].get(prodList.data).toString() 
               //int j=0;
               boolean isProductFound=false;
               try{
                   while(prodList!=null){
                    //for(;j<prodList.size();j++){
                    int prodID =Integer.parseInt(field[0].get(prodList.data).toString());
                    if(orderList.get(i).prodID==prodID){
                        isProductFound=true;
                        break;
                    }
                    prodList=prodList.next;
                  }
                    if(isProductFound)
                    { 
                       String quantity = ""+field[3].get(prodList.data).toString();
                       String price = ""+field[4].get(prodList.data).toString();
                       String size = ""+field[8].get(prodList.data).toString();

                       pane.add(new Label(field[1].get(prodList.data).toString()),0,row);
                     //  pane.add(new Label(orderList.get(i).userEmail),1,row);
                       pane.add(new Label(field[2].get(prodList.data).toString()),2,row);
                       pane.add(new Label(quantity),3,row);
                       pane.add(new Label(price),5,row);
                       pane.add(new Label(field[5].get(prodList.data).toString()),4,row);
                       pane.add(new Label(field[6].get(prodList.data).toString()),6,row);
                       pane.add(new Label(field[7].get(prodList.data).toString()),7,row);
                       pane.add(new Label(size),8,row);
                       row++;
                    }
                }
                catch(Exception e){
                   Alert a = new Alert(AlertType.ERROR,"Something went wrong");         
                }
            }
       }
       Button backbtn=new Button("Back");
       pane.add(backbtn,0,row);
       backbtn.addEventHandler(MouseEvent.MOUSE_CLICKED,new EventHandler<MouseEvent>() {
            public void handle(MouseEvent event) {
               viewProductCustomer(GridPane1,stage);
            }
        });
       stage.close();
       Scene scene2 = new Scene(pane);
       stage.setTitle("Product List");
       stage.setScene(scene2);
       stage.show();
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
