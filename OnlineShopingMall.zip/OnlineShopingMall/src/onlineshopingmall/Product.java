package onlineshopingmall;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author M.Ali
 */
public class Product {
    protected int prodid;
    protected String prodName;
    protected String category;
    protected int quantity;
    protected double price;
    protected String productCompany;
    protected String prodDesc;
    protected String prodColor;
    protected double prodSize;
    //protected List<ProductEntries> prodList= new ArrayList<ProductEntries>();
    protected Node prodList;
    public Product(){
        prodid=0;
        prodName="";
        category="";
        quantity=0;
        price=0.0;
        productCompany="";
        prodDesc="";
        prodColor="";
        prodSize=0.0;
        prodList=null;
    }
   
    public boolean addProduct(String prodName, String category,int quantity,double price,String productCompany,String prodDesc,String prodColor,double prodSize){
       // ProductEntries prodEntry = new ProductEntries();
        boolean checkval=true;
        if(prodName.length()==0)
          checkval=false;
        else
          this.prodName=prodName;
        if(category.length()>0 && checkval)
           this.category=category;
        else
           checkval=false;
        if(quantity>0 && checkval)
           this.quantity=quantity;
        else
           checkval=false;
        if(price>0.0 && checkval)
           this.price=price;
        else
           checkval=false;
        if(productCompany.length()>0 && checkval)
           this.productCompany=productCompany;
        else    
           checkval=false;
        if(prodDesc.length()>0 && checkval)
           this.prodDesc=prodDesc;
        else
           checkval=false;
        this.prodColor="";
        if(prodColor.length()>0 && checkval)
            this.prodColor=prodColor;
        this.prodSize=0.0;
        if(prodSize>0.0 && checkval)
            this.prodSize=prodSize;
        this.prodid = ++this.prodid;
        if(checkval){
            // prodList.add(prodEntry);
           Product prodObj=new Product();
           prodObj.prodid=this.prodid;
           prodObj.prodName=this.prodName;
           prodObj.category=this.category;
           prodObj.quantity=this.quantity;
           prodObj.price=this.price;
           prodObj.productCompany=this.productCompany;
           prodObj.prodDesc=this.prodDesc;
           prodObj.prodColor=this.prodColor;
           prodObj.prodSize=this.prodSize;
           if(prodid>1){
               //System.out.println("chexck:"+prodObj.prodName);
              prodList.insert(prodObj);
           }
           else{
               //System.out.println("chexck2");
               prodList = new Node(prodObj);
           } 
        }
        return checkval;
    }
    
    /*
    public boolean EditProduct(int prodid, String prodName, String category,int quantity,double price,String productCompany,String prodDesc,String prodColor,double prodSize){
        ProductEntries prodEntry = new ProductEntries();
        boolean checkval=true;
        if(prodName.length()==0)
          checkval=false;
        else
          prodEntry.prodName=prodName;
        if(category.length()>0 && checkval)
           prodEntry.category=category;
        else
            checkval=false;
        if(quantity>0 && checkval)
           prodEntry.quantity=quantity;
        else
           checkval=false;
        if(price>0.0 && checkval)
           prodEntry.price=price;
        else
           checkval=false;
        if(productCompany.length()>0 && checkval)
           prodEntry.productCompany=productCompany;
        else    
           checkval=false;
        if(prodDesc.length()>0 && checkval)
           prodEntry.prodDesc=prodDesc;            
        else
           checkval=false;
        prodEntry.prodColor="";
        if(prodColor.length()>0 && checkval)
            prodEntry.prodColor=prodColor;
        prodEntry.prodSize=0.0;
        if(prodSize>0.0 && checkval)
            prodEntry.prodSize=prodSize;
        if(checkval){
            for(int i=0;i<this.prodList.size();i++){
                if(this.prodList.get(i).prodid == prodid){
                   prodList.set(i,prodEntry);
                    break;
                }
            }
        }
        return checkval;
    }
    public boolean delProd(int prodid){
        boolean chckVal=false;
        for(int i=0;i<this.prodList.size();i++){
            if(this.prodList.get(i).prodid == prodid){
               prodList.remove(i);
               chckVal=true;
               break;
            }
        }
        return chckVal;
    }
    public List getProduct(){
        return this.prodList;
    }
   */
}
/*
class ProductEntries extends Product{
     public int getMaxProdID(){
        int max=1;
        if(super.prodList.size()>0){
            max=super.prodList.get(0).prodid;
            for(int i=1;i<super.prodList.size();i++){
                if(super.prodList.get(i).prodid>max)
                {
                    max=super.prodList.get(i).prodid;
                }
            }
        }
        return max;
    }
}
*/
