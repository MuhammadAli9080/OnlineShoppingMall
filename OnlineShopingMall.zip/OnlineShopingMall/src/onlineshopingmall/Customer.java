package onlineshopingmall;
import onlineshopingmall.Person;
/**
 *
 * @author M.Ali
 */
public class Customer extends Person{
    //public int Custid;
    public Customer(){
        int Custid=super.uid;
        utype=2;
    }
}
