package onlineshopingmall;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
/**
 *
 * @author M.Ali
 */
public class Person {
   public int uid;
   protected String name;
   protected String email;
   protected String password;
   protected String contact;
   private List<Customer> CustomerList=new ArrayList<Customer>();
   private List<Admin> adminList=new ArrayList<Admin>();
   protected int utype;
   public int getUtype(){
       return utype;
   }
   public void setUtype(int uType){
       this.utype=uType;
   }
   public Person()  {
       this.uid=getMaxUID();
       this.name="";
       this.email="";
       this.password="";
       this.contact="";
   }
   public Person( String name,String email,String password,String contact,int utype,String address, char gender){
       this.uid=getMaxUID();
       this.name=name;
       this.email=email;
       this.password=password;
       this.contact=contact;
   }
   public int getMaxUID(){
        int max=1;
        if(CustomerList.size()>0){
            max=CustomerList.get(0).uid;
            for(int i=1;i<CustomerList.size();i++){
                if(CustomerList.get(i).uid>max)
                {
                    max=CustomerList.get(i).uid;
                }
            }
        }
        return max;
    }
   public String getLogin(String email, String pass){
        String Email=""; 
        Person person;
        Iterator personIterate = CustomerList.iterator();
        while (personIterate.hasNext()) {
            person= (Person) personIterate.next(); 
            if(person.email.equals(email) && person.password.equals(pass)){
               Email=email;
               break; 
            }
        }
       return Email;
   }
   public boolean getSignup(String name,String contact,int utype,String email, String pass){
       boolean isNotEmpty=false;
       if(email.length()!=0 && pass.length()!=0)
       {
           Person person;
           Customer customer=new Customer();
           Iterator personIterate = CustomerList.iterator();
             while (personIterate.hasNext()) {
                 person= (Person) personIterate.next(); 
                 if(person.email.equals(email)){
                     return false;
                 }
             }
             customer.name=name;
             customer.contact=contact;
             customer.utype=utype;
             customer.email=email;
             customer.password=pass;
             CustomerList.add(customer); 
             isNotEmpty = true;
       }
       return isNotEmpty;
   }
   public List getCustomers(){
        return this.CustomerList;
   }
   public boolean AdminLogin(String email,String pass){
       Admin admin = new Admin();
       if(email.equals(admin.email)){
           if(pass.equals(admin.password)){
             return true;  
           }
       }
       return false;
   }
}
