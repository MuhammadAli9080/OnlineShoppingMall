package onlineshopingmall;
import onlineshopingmall.Person;

/**
 *
 * @author M.Ali
 */
public class Admin extends Person{
    public Admin(){
        super.email = "admin@onshopping.com";
        super.password = "123456";
        utype=2;
    }   
}
